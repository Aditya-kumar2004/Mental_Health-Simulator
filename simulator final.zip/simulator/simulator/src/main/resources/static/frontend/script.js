const BASE_URL = 'http://localhost:8080/api';

function registerUser() {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch(`${BASE_URL}/users/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password })
    })
    .then(response => response.json())
    .then(data => {
        // Store user ID in localStorage for later use
        localStorage.setItem('userId', data.id);
        document.getElementById('register-message').innerText = `Registered! Your User ID is ${data.id}. Redirecting to mood page...`;
        
        // Redirect to mood page after 2 seconds
        setTimeout(() => {
            window.location.href = 'mood.html';
        }, 2000);
    })
    .catch(error => {
        document.getElementById('register-message').innerText = 'Error registering.';
    });
}

function loginUser() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch(`${BASE_URL}/users/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.text())
    .then(data => {
        if (data.includes('successful')) {
            // Extract user ID from success message (e.g., "Login successful. User ID: 2")
            const match = data.match(/User ID: (\d+)/);
            if (match) {
                const userId = match[1];
                localStorage.setItem('userId', userId);
                document.getElementById('login-message').innerText = data + ' Redirecting to mood page...';
                
                // Redirect to mood page after 2 seconds
                setTimeout(() => {
                    window.location.href = 'mood.html';
                }, 2000);
            } else {
                document.getElementById('login-message').innerText = data;
            }
        } else {
            document.getElementById('login-message').innerText = data;
        }
    })
    .catch(error => {
        document.getElementById('login-message').innerText = 'Error logging in.';
    });
}

function logMood() {
    const savedUserId = localStorage.getItem('userId');
    const mood = document.getElementById('selectedMood').value;
    const notes = document.getElementById('notes').value;

    console.log('Logging mood:', { savedUserId, mood, notes }); // Debug log

    if (!savedUserId) {
        document.getElementById('mood-message').innerText = 'Please register first to log your mood.';
        return;
    }

    if (!mood) {
        document.getElementById('mood-message').innerText = 'Please select a mood.';
        return;
    }

    document.getElementById('mood-message').innerText = 'Logging mood...';

    fetch(`${BASE_URL}/moods/${savedUserId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mood, intensity: 5, notes }) // Default intensity to 5
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
    })
    .then(data => {
        console.log('Mood logged response:', data); // Debug log
        document.getElementById('mood-message').innerText = 'Mood logged successfully!';
        
        // Wait a moment before clearing and refreshing to ensure save is complete
        setTimeout(() => {
            // Clear form
            document.querySelectorAll('.mood-option').forEach(option => {
                option.classList.remove('selected');
            });
            document.getElementById('selectedMood').value = '';
            document.getElementById('notes').value = '';
            
            // Refresh mood history
            getMoodHistory(savedUserId);
        }, 500);
    })
    .catch(error => {
        console.error('Error logging mood:', error); // Debug log
        document.getElementById('mood-message').innerText = 'Error logging mood: ' + error.message;
    });
}

function getMoodHistory(userId) {
    console.log('Getting mood history for user:', userId); // Debug log
    
    fetch(`${BASE_URL}/moods/${userId}`)
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Mood history received:', data); // Debug log
        const historyDiv = document.getElementById('mood-history');
        historyDiv.innerHTML = '';
        
        if (data.length === 0) {
            historyDiv.innerHTML = '<p class="no-history">No mood entries yet. Start logging your mood!</p>';
            return;
        }
        
        // Sort by timestamp descending (newest first)
        data.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        data.forEach(mood => {
            const div = document.createElement('div');
            div.className = 'mood-history-item';
            
            const emoji = getMoodEmoji(mood.mood);
            const date = new Date(mood.timestamp).toLocaleDateString();
            const time = new Date(mood.timestamp).toLocaleTimeString();
            
            div.innerHTML = `
                <span class="emoji">${emoji}</span>
                <div class="mood-details">
                    <div class="mood-name">${mood.mood}</div>
                    <div class="mood-timestamp">${date} at ${time}</div>
                    ${mood.notes ? `<div class="mood-notes">"${mood.notes}"</div>` : ''}
                </div>
            `;
            historyDiv.appendChild(div);
        });
    })
    .catch(error => {
        console.error('Error loading mood history:', error); // Debug log
        document.getElementById('mood-history').innerHTML = '<p class="error">Error loading history: ' + error.message + '</p>';
    });
}

function getMoodEmoji(mood) {
    const emojiMap = {
        'Awful': '😭',
        'Sad': '😞',
        'Existing': '😐',
        'Good': '😊',
        'Elated': '😁',
        // Keep old moods for backward compatibility
        'Happy': '�',
        'Anxious': '😰',
        'Excited': '🤩',
        'Calm': '😌',
        'Angry': '😠'
    };
    return emojiMap[mood] || '😐';
}

function suggestActivity() {
    fetch(`${BASE_URL}/activities/suggest`)
    .then(response => response.text())
    .then(data => {
        document.getElementById('activity-suggestion').innerText = data;
    })
    .catch(error => {
        document.getElementById('activity-suggestion').innerText = 'Error getting activity.';
    });
}

function getAllActivities() {
    fetch(`${BASE_URL}/activities`)
    .then(response => response.json())
    .then(data => {
        const listDiv = document.getElementById('activities-list');
        listDiv.innerHTML = '';
        data.forEach(activity => {
            const p = document.createElement('p');
            p.innerText = `${activity.name}: ${activity.description}`;
            listDiv.appendChild(p);
        });
    })
    .catch(error => {
        document.getElementById('activities-list').innerText = 'Error loading activities.';
    });
}

function getRandomQuote() {
    fetch(`${BASE_URL}/quotes/random`)
    .then(response => response.text())
    .then(data => {
        document.getElementById('quote-display').innerText = data;
    })
    .catch(error => {
        document.getElementById('quote-display').innerText = 'Error getting quote.';
    });
}

function getAllQuotes() {
    fetch(`${BASE_URL}/quotes`)
    .then(response => response.json())
    .then(data => {
        const listDiv = document.getElementById('quotes-list');
        listDiv.innerHTML = '';
        data.forEach(quote => {
            const p = document.createElement('p');
            p.innerText = `"${quote.text}" - ${quote.author}`;
            listDiv.appendChild(p);
        });
    })
    .catch(error => {
        document.getElementById('quotes-list').innerText = 'Error loading quotes.';
    });
}

if (window.location.pathname.includes('activities.html')) {
    getAllActivities();
}
if (window.location.pathname.includes('quotes.html')) {
    getAllQuotes();
}