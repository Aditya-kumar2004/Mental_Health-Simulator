package com.mentalhealth.simulator.service;

import com.mentalhealth.simulator.model.CalmActivity;
import com.mentalhealth.simulator.repository.CalmActivityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class CalmActivityService {
    @Autowired
    private CalmActivityRepository activityRepository;

    public List<CalmActivity> findAll() {
        return activityRepository.findAll();
    }

    public String suggestActivity() {
        List<CalmActivity> activities = findAll();
        if (activities.isEmpty()) {
            return "No activities available.";
        }
        CalmActivity activity = activities.get(new Random().nextInt(activities.size()));
        return activity.getName() + ": " + activity.getDescription();
    }
}