package com.mentalhealth.simulator.repository;

import com.mentalhealth.simulator.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}