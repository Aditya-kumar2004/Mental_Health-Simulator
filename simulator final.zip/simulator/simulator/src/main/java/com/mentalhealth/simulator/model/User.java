package com.mentalhealth.simulator.model;

import lombok.Data;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Data
@Entity
@Table(name = "users") // Use "users" instead of "user" to avoid H2 reserved keyword
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String email;
    private String password; // Store plain password for simplicity (use hashing in production)
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    @JsonIgnore // Prevent circular reference during JSON serialization
    private List<MoodTracker> moodHistory;
}