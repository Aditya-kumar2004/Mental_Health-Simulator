package com.mentalhealth.simulator.controller;

import com.mentalhealth.simulator.model.Quote;
import com.mentalhealth.simulator.service.QuoteProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/quotes")
public class QuoteController {
    @Autowired
    private QuoteProvider quoteProvider;

    @GetMapping
    public List<Quote> getAllQuotes() {
        return quoteProvider.findAll();
    }

    @GetMapping("/random")
    public String getRandomQuote() {
        return quoteProvider.getRandomQuote();
    }
}