package com.mentalhealth.simulator.model;

import lombok.Data;
import jakarta.persistence.*;

@Data
@Entity
public class Quote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String text;
    private String author;
    private String category;

    public Quote() {
    }

    public Quote(Long id, String text, String author, String category) {
        this.id = id;
        this.text = text;
        this.author = author;
        this.category = category;
    }
}