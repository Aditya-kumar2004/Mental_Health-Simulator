package com.mentalhealth.simulator.service;

import com.mentalhealth.simulator.model.MoodTracker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Assistant {

    @Autowired
    private CalmActivityService calmActivityService;

    @Autowired
    private QuoteProvider quoteProvider;

    public String respondToMood(MoodTracker mood) {
        String response;
        switch (mood.getMood().toLowerCase()) {
            case "sad":
                response = "I'm sorry you're feeling sad. Try " + calmActivityService.suggestActivity() +
                        ". Here's a quote: " + quoteProvider.getQuoteForMood(mood);
                break;
            case "anxious":
                response = "Feeling anxious? Try " + calmActivityService.suggestActivity();
                break;
            default:
                response = "Thanks for sharing! How about " + calmActivityService.suggestActivity() + "?";
        }
        return response;
    }

    public String greetUser() {
        return "Hi! How are you feeling today?";
    }

    // ✅ Add this method:
    public String getUserGreeting(Long userId) {
        return "Hello, user #" + userId + "! How are you feeling today?";
    }
}
