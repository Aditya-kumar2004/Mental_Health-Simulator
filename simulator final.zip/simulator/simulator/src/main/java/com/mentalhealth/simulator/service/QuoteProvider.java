package com.mentalhealth.simulator.service;

import com.mentalhealth.simulator.model.MoodTracker;
import com.mentalhealth.simulator.model.Quote;
import com.mentalhealth.simulator.repository.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class QuoteProvider {
    @Autowired
    private QuoteRepository quoteRepository;

    public List<Quote> findAll() {
        return quoteRepository.findAll();
    }

    public String getRandomQuote() {
        List<Quote> quotes = findAll();
        if (quotes.isEmpty()) {
            return "No quotes available.";
        }
        Quote quote = quotes.get(new Random().nextInt(quotes.size()));
        return "\"" + quote.getText() + "\" - " + quote.getAuthor();
    }

    public String getQuoteForMood(MoodTracker mood) {
        String category = mood.getMood().equalsIgnoreCase("sad") ? "Motivational" : "Calming";
        List<Quote> quotes = quoteRepository.findByCategory(category);
        if (quotes.isEmpty()) {
            return getRandomQuote();
        }
        Quote quote = quotes.get(new Random().nextInt(quotes.size()));
        return "\"" + quote.getText() + "\" - " + quote.getAuthor();
    }
}