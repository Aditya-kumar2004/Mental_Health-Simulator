package com.mentalhealth.simulator.controller;

import com.mentalhealth.simulator.model.MoodTracker;
import com.mentalhealth.simulator.service.Executor;
import com.mentalhealth.simulator.service.MoodTrackerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/moods")
public class MoodController {
    @Autowired
    private Executor executor;
    @Autowired
    private MoodTrackerService moodService;

    @PostMapping("/{userId}")
    public String logMood(@PathVariable Long userId, @RequestBody MoodTracker mood) {
        return executor.processMoodEntry(userId, mood);
    }

    @GetMapping("/{userId}")
    public List<MoodTracker> getMoodHistory(@PathVariable Long userId) {
        return moodService.findByUserId(userId);
    }
}