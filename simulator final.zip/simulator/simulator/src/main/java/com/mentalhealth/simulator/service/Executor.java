package com.mentalhealth.simulator.service;

import com.mentalhealth.simulator.model.MoodTracker;
import com.mentalhealth.simulator.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class Executor {

    @Autowired
    private UserService userService;

    @Autowired
    private MoodTrackerService moodService;

    @Autowired
    private Assistant assistant;

    @SuppressWarnings("unused")
    @Autowired
    private CalmActivityService activityService; // TODO: Use this for advanced activity logic

    @Autowired
    private QuoteProvider quoteProvider;

    public String processMoodEntry(Long userId, MoodTracker mood) {
        User user = userService.findById(userId);
        if (user == null) {
            return "User not found.";
        }

        mood.setUser(user);
        mood.setTimestamp(LocalDateTime.now());
        moodService.save(mood);

        String assistantResponse = assistant.respondToMood(mood);
        String quote = quoteProvider.getQuoteForMood(mood);

        return assistantResponse + "\nHere's a quote for you: " + quote;
    }

    public String getUserGreeting(Long userId) {
        User user = userService.findById(userId);
        if (user == null) {
            return "User not found.";
        }

        // Personalized greeting using user's name or username
        return "Hello, " + user.getUsername() + "! " + assistant.greetUser();
    }
}
