package com.mentalhealth.simulator.model;

import lombok.Data;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Data
@Entity
public class CalmActivity {
    @Id
    private String name;
    private String description;

    public CalmActivity() {
    }

    public CalmActivity(String name, String description) {
        this.name = name;
        this.description = description;
    }
}