package com.mentalhealth.simulator.config;

import com.mentalhealth.simulator.model.CalmActivity;
import com.mentalhealth.simulator.model.Quote;
import com.mentalhealth.simulator.repository.CalmActivityRepository;
import com.mentalhealth.simulator.repository.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private CalmActivityRepository activityRepository;

    @Autowired
    private QuoteRepository quoteRepository;

    @Override
    public void run(String... args) throws Exception {
        // Initialize calm activities
        if (activityRepository.count() == 0) {
            activityRepository.save(new CalmActivity("Deep Breathing", "Take slow, deep breaths for 5 minutes"));
            activityRepository.save(new CalmActivity("Meditation", "Practice mindfulness meditation"));
            activityRepository.save(new CalmActivity("Nature Walk", "Take a peaceful walk in nature"));
            activityRepository.save(new CalmActivity("Journaling", "Write down your thoughts and feelings"));
        }

        // Initialize quotes
        if (quoteRepository.count() == 0) {
            quoteRepository.save(new Quote(null, "The present moment is the only time over which we have dominion.",
                    "Thich Nhat Hanh", "mindfulness"));
            quoteRepository.save(new Quote(null, "You are not your thoughts. You are the observer of your thoughts.",
                    "Eckhart Tolle", "self-awareness"));
            quoteRepository
                    .save(new Quote(null, "Peace comes from within. Do not seek it without.", "Buddha", "inner-peace"));
            quoteRepository.save(new Quote(null,
                    "The greatest weapon against stress is our ability to choose one thought over another.",
                    "William James", "stress-relief"));
        }
    }
}
