package com.mentalhealth.simulator.controller;

import com.mentalhealth.simulator.model.CalmActivity;
import com.mentalhealth.simulator.service.CalmActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/activities")
public class ActivityController {
    @Autowired
    private CalmActivityService activityService;

    @GetMapping
    public List<CalmActivity> getAllActivities() {
        return activityService.findAll();
    }

    @GetMapping("/suggest")
    public String suggestActivity() {
        return activityService.suggestActivity();
    }
}