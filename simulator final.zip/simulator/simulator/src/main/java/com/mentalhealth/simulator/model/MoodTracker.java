package com.mentalhealth.simulator.model;

import lombok.Data;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDateTime;

@Data
@Entity
public class MoodTracker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String mood;
    private int intensity;
    private String notes;
    private LocalDateTime timestamp;
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnore // Prevent circular reference during JSON serialization
    private User user;
}