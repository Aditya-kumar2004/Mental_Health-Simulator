package com.mentalhealth.simulator.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebController {

    @RequestMapping("/")
    public String index() {
        return "forward:/frontend/index.html";
    }

    @RequestMapping("/login")
    public String login() {
        return "forward:/frontend/login.html";
    }

    @RequestMapping("/register")
    public String register() {
        return "forward:/frontend/register.html";
    }

    @RequestMapping("/mood")
    public String mood() {
        return "forward:/frontend/mood.html";
    }

    @RequestMapping("/activities")
    public String activities() {
        return "forward:/frontend/activities.html";
    }

    @RequestMapping("/quotes")
    public String quotes() {
        return "forward:/frontend/quotes.html";
    }
}
