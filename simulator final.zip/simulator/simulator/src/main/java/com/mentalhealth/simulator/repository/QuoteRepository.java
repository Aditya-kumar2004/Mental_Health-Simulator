package com.mentalhealth.simulator.repository;

import com.mentalhealth.simulator.model.Quote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface QuoteRepository extends JpaRepository<Quote, Long> {
    List<Quote> findByCategory(String category);
}