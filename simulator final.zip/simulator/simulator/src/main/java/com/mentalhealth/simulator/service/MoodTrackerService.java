package com.mentalhealth.simulator.service;

import com.mentalhealth.simulator.model.MoodTracker;
import com.mentalhealth.simulator.repository.MoodRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MoodTrackerService {
    @Autowired
    private MoodRepository moodRepository;

    public MoodTracker save(MoodTracker mood) {
        return moodRepository.save(mood);
    }

    public List<MoodTracker> findByUserId(Long userId) {
        return moodRepository.findByUserId(userId);
    }
}