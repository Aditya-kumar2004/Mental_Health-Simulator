package com.mentalhealth.simulator.repository;

import com.mentalhealth.simulator.model.MoodTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MoodRepository extends JpaRepository<MoodTracker, Long> {
    List<MoodTracker> findByUserId(Long userId);
}