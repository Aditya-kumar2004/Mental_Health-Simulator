package com.mentalhealth.simulator.repository;

import com.mentalhealth.simulator.model.CalmActivity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CalmActivityRepository extends JpaRepository<CalmActivity, String> {
}
