package com.mentalhealth.simulator.controller;

import com.mentalhealth.simulator.service.Assistant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/assistant")
public class AssistantController {
    @Autowired
    private Assistant assistant;

    @GetMapping("/greet/{userId}")
    public String greetUser(@PathVariable Long userId) {
        return assistant.getUserGreeting(userId);
    }
    
}
