# Deployment Guide 🚀

This guide provides instructions for deploying the Mental Health Simulator application to various platforms.

## Prerequisites

- Java 17+
- Maven 3.6+
- Git

## Local Development Setup

1. **Clone and run locally:**
   ```bash
   git clone <repository-url>
   cd Mental_Health_Simulator
   ./mvnw spring-boot:run
   ```

2. **Access the application:**
   - Application: http://localhost:8080
   - H2 Console: http://localhost:8080/h2-console

## Production Deployment Options

### 1. JAR Deployment

**Build the JAR:**
```bash
./mvnw clean package
```

**Run the JAR:**
```bash
java -jar target/simulator-0.0.1-SNAPSHOT.jar
```

**With custom port:**
```bash
java -jar target/simulator-0.0.1-SNAPSHOT.jar --server.port=8081
```

### 2. Docker Deployment

**Create Dockerfile:**
```dockerfile
FROM openjdk:17-jdk-slim

WORKDIR /app

COPY target/simulator-0.0.1-SNAPSHOT.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
```

**Build and run:**
```bash
./mvnw clean package
docker build -t mental-health-simulator .
docker run -p 8080:8080 mental-health-simulator
```

### 3. Cloud Deployment

#### Heroku
```bash
# Install Heroku CLI
heroku create your-app-name
git push heroku main
```

#### Railway
```bash
# Install Railway CLI
railway login
railway init
railway up
```

## Database Configuration for Production

### PostgreSQL Setup
```properties
# application-prod.properties
spring.datasource.url=jdbc:postgresql://localhost:5432/mentalhealth
spring.datasource.username=${DB_USERNAME}
spring.datasource.password=${DB_PASSWORD}
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

### MySQL Setup
```properties
# application-prod.properties
spring.datasource.url=jdbc:mysql://localhost:3306/mentalhealth
spring.datasource.username=${DB_USERNAME}
spring.datasource.password=${DB_PASSWORD}
spring.jpa.database-platform=org.hibernate.dialect.MySQL8Dialect
```

## Environment Variables

Set these environment variables for production:

```bash
export SPRING_PROFILES_ACTIVE=prod
export DB_USERNAME=your_db_user
export DB_PASSWORD=your_db_password
export SERVER_PORT=8080
```

## Security Considerations

1. **Change default passwords**
2. **Use HTTPS in production**
3. **Implement proper authentication**
4. **Add rate limiting**
5. **Configure CORS properly**

## Monitoring and Logging

Add to `application-prod.properties`:
```properties
# Logging
logging.level.com.mentalhealth.simulator=INFO
logging.file.name=logs/application.log

# Actuator for monitoring
management.endpoints.web.exposure.include=health,info,metrics
```

## Performance Optimization

```properties
# JVM options for production
-Xms512m -Xmx2g
-XX:+UseG1GC
-XX:MaxGCPauseMillis=200
```

## Backup Strategy

1. **Database backups**
2. **Application logs**
3. **Configuration files**

## Health Checks

The application provides health endpoints:
- `/actuator/health` - Application health status
- `/actuator/info` - Application information

## Troubleshooting

### Common Production Issues

1. **Out of Memory:**
   ```bash
   java -Xmx2g -jar app.jar
   ```

2. **Port conflicts:**
   ```bash
   java -jar app.jar --server.port=8081
   ```

3. **Database connection:**
   - Check network connectivity
   - Verify credentials
   - Check firewall settings

## Scaling

### Horizontal Scaling
- Use load balancer
- Multiple application instances
- Shared database

### Vertical Scaling
- Increase memory: `-Xmx4g`
- More CPU cores
- SSD storage

## Continuous Integration/Deployment

### GitHub Actions Example
```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Set up JDK 17
      uses: actions/setup-java@v2
      with:
        java-version: '17'
    - name: Build with Maven
      run: ./mvnw clean package
    - name: Deploy to production
      run: # Add your deployment commands here
```

## Support

For deployment issues:
1. Check application logs
2. Verify environment variables
3. Test database connectivity
4. Contact system administrator
