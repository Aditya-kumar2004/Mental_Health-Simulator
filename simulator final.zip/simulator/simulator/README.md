# Mental Health Simulator 🧠💚

A comprehensive mental health tracking and support application built with Spring Boot and modern web technologies.

## 🌟 Features

- **User Registration & Authentication**: Secure user account management
- **Mood Tracking**: Log daily moods with emoji-based selection and notes
- **Mood History**: View personalized mood patterns over time
- **Calming Activities**: Get personalized activity suggestions
- **Inspirational Quotes**: Daily motivational quotes for mental wellness
- **Responsive Design**: Works seamlessly on desktop and mobile devices

## 🛠️ Technology Stack

### Backend
- **Spring Boot 3.5.3** - Main application framework
- **Java 17** - Programming language
- **H2 Database** - In-memory database for development
- **JPA/Hibernate** - Object-relational mapping
- **Maven** - Dependency management and build tool
- **Lombok** - Reduces boilerplate code

### Frontend
- **HTML5** - Markup language
- **CSS3** - Styling with Flexbox layouts
- **JavaScript** - Client-side interactivity
- **Responsive Design** - Mobile-first approach

## 🚀 Getting Started

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/Aditya-kumar2004/Mental_Health_Simulator.git
   cd Mental_Health_Simulator
   ```

2. **Build the project**
   ```bash
   ./mvnw clean compile
   ```

3. **Run the application**
   ```bash
   ./mvnw spring-boot:run
   ```

4. **Access the application**
   - Open your browser and navigate to: `http://localhost:8080`
   - The application will be running on port 8080

### Alternative Run Methods

**Using Maven wrapper (Windows):**
```cmd
mvnw.cmd spring-boot:run
```

**Using Maven directly:**
```bash
mvn spring-boot:run
```

## 📱 Application Features

### 🔐 User Management
- **Register**: Create a new user account
- **Login**: Authenticate existing users
- **Session Management**: Persistent user sessions using localStorage

### 😊 Mood Tracking
- **Emoji Selection**: Choose from 5 mood levels (😭 😞 😐 😊 😁)
- **Notes**: Add optional notes about your mood
- **History**: View all previous mood entries with timestamps
- **Visual Interface**: Horizontal mood selection with hover effects

### 🌿 Wellness Features
- **Activity Suggestions**: Get personalized calming activities
- **Quote of the Day**: Inspirational quotes for motivation
- **Responsive Design**: Optimized for all device sizes

## 🗂️ Project Structure

```
src/
├── main/
│   ├── java/com/mentalhealth/simulator/
│   │   ├── controller/          # REST API controllers
│   │   ├── model/              # JPA entities
│   │   ├── repository/         # Data access layer
│   │   ├── service/            # Business logic
│   │   └── config/             # Configuration classes
│   └── resources/
│       ├── static/frontend/    # Frontend files (HTML, CSS, JS)
│       └── application.properties
└── test/                       # Unit tests
```

## 🎯 API Endpoints

### User Management
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - User authentication
- `GET /api/users/{id}` - Get user details

### Mood Tracking
- `POST /api/moods/{userId}` - Log a new mood entry
- `GET /api/moods/{userId}` - Get user's mood history

### Activities & Quotes
- `GET /api/activities/suggest` - Get random activity suggestion
- `GET /api/activities` - Get all activities
- `GET /api/quotes/random` - Get random inspirational quote
- `GET /api/quotes` - Get all quotes

## 🛡️ Security Features

- Password-based authentication
- Session management with localStorage
- Input validation and sanitization
- CORS configuration for frontend-backend communication

## 🗄️ Database Schema

### User Entity
- `id` (Primary Key)
- `username`
- `email` (Unique)
- `password`

### MoodTracker Entity
- `id` (Primary Key)
- `mood` (String)
- `intensity` (Integer)
- `notes` (Text)
- `timestamp` (LocalDateTime)
- `user_id` (Foreign Key)

### Additional Entities
- **CalmActivity**: Wellness activities
- **Quote**: Inspirational quotes

## 🔧 Configuration

### Database Configuration
The application uses H2 in-memory database by default. Database settings in `application.properties`:

```properties
spring.datasource.url=jdbc:h2:mem:mentalhealth
spring.h2.console.enabled=true
spring.jpa.hibernate.ddl-auto=create-drop
```

### Access H2 Console
- URL: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:mentalhealth`
- Username: `sa`
- Password: (leave empty)

## 🐛 Troubleshooting

### Common Issues

1. **Port 8080 already in use**
   ```properties
   # Add to application.properties
   server.port=8081
   ```

2. **Database connection issues**
   - Check H2 console at `/h2-console`
   - Verify JDBC URL: `jdbc:h2:mem:mentalhealth`

3. **Frontend not loading**
   - Clear browser cache
   - Check browser console for JavaScript errors

## 🚀 Deployment

### Production Considerations
- Replace H2 with persistent database (PostgreSQL, MySQL)
- Add proper security configurations
- Implement proper error handling
- Add logging configuration
- Set up environment-specific configurations

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Authors

- **Development Team** - Initial work and implementation
- **Contributors** - See contributors list for full details

## 🙏 Acknowledgments

- Spring Boot community for excellent documentation
- Mental health awareness initiatives
- Open source contributors

## 📞 Support

If you encounter any issues or have questions:
1. Check the troubleshooting section
2. Open an issue on GitHub
3. Contact the development team

---

**Note**: This application is for educational and demonstration purposes. For serious mental health concerns, please consult with qualified healthcare professionals.
